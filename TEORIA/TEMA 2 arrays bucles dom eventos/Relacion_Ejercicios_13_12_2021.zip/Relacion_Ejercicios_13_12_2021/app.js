/**
Ejercicio 1
*/
/**
 *
//  * @param {Number} ms
//  * @returns {Promise}
//  */
// function retardo(ms) {
//   return new Promise(function (resolve, reject) {
//     setTimeout(function () {
//       resolve(`Estoy detenido ${ms / 1000} segundos`);
//     }, ms);
//   });
// }

// retardo(3000).then((respuesta) => {
//   alert(respuesta);
// });

/**
---------------------- Ejercicio 3 --------------------------
*/

/**
 *
 * @param {Date} fecha
 * @returns {Promise}
 */
// function insertarFecha(fecha) {
//   return new Promise(function (resolve, reject) {
//     if (typeof Storage != undefined) {
//       // puedo almacenar en localstorage
//       resolve(localStorage.setItem("Fecha", fecha));
//     } else {
//       // no puedo almacenar en localstorage
//       reject("Tu navegador no puede almacenar en Storage");
//     }
//   });
// }

// insertarFecha(new Date(Date.now()).toLocaleDateString())
//   .then(() =>
//     console.log("Fecha almacenada -> ", localStorage.getItem("Fecha"))
//   )
//   .catch(console.log);

// ---------------------- CONSUMIR API --------------------------

// uso de la API fetch("https://jsonplaceholder.typicode.com/albums")

// const urlAPI = "https://jsonplaceholder.typicode.com";
// const codigoHTML = document.querySelector("#aplicacion");

// ------ no usar esta forma ------------ No recomendado -------
// fetch(`${urlAPI}/users`)
//   .then((response) => response.json())
//   .then((users) => {
//     const template = users.map(
//       (user) => `<li> 🤷‍♂️ ${user.name} 📧 ${user.email}<li>`
//     );
//     codigoHTML.innerHTML = `<ul>${template}</ul>`;
//   });

// ------------- usar esta forma ----------

// const ul = document.createElement("ul");

// fetch(`${urlAPI}/users`)
//   .then((response) => response.json())
//   .then((users) => {
//     users.forEach((user) => {
//       let elementoLi = document.createElement("li");
//       elementoLi.appendChild(
//         document.createTextNode(`🤷‍♂️ ${user.name} 📧 ${user.email}`)
//       );
//       ul.appendChild(elementoLi);
//     });
//     codigoHTML.appendChild(ul);
//   })
//   .catch("Error al consumir la API");

// -------------- Comparación de Fetch con Asinc Await --------------------

// fetch("https://jsonplaceholder.typicode.com/posts/1")
//   .then((response) => response.json())
//   .then((posts) => {
//     console.log(posts);
//   })
//   .catch((error) => {
//     console.log(error);
//   });

// async function fetchAPI() {
//   try {
//     let response = await fetch("https://jsonplaceholder.typicode.com/posts/1");
//     debugger;
//     if (response.status === 200) {
//       let posts = await response.json();
//       console.log(posts);
//     }
//   } catch (error) {
//     console.log(error);
//   }
// }
// fetchAPI();

// ----------------- GET Y POST en REST API ---------------------------

// ------------------ GET
// fetch("https://jsonplaceholder.typicode.com/todos")
//   .then((response) => response.json())
//   .then((posts) => {
//     console.log(posts);
//   });

//  ----------------- POST
// userId: 1, id: 1, title: 'delectus aut autem', completed: false
// fetch("https://jsonplaceholder.typicode.com/posts", {
//   headers: {},
//   method: "POST",
//   body: JSON.stringify({
//     title: "Prueba de clase",
//     body: "bar",
//     userId: 1,
//   }),
//   headers: {
//     "Content-type": "application/json; charset=UTF-8",
//   },
// })
//   .then((response) => response.json())
//   .then((users) => {
//     console.log(users);
//   });

// ------------------ Encadenar dos promesas ---------------------
/**
 * @author Isaías FL.
 * @description Ejemplo de promesas
 */
const listaUsuarios = [
  { id: 1, nombre: "Luis", codPais: 3 },
  { id: 2, nombre: "Alfred", codPais: 1 },
  { id: 3, nombre: "Pascal", codPais: 2 },
];
const listaPaises = { 1: "Francia", 2: "Bélgica", 3: "España" };

// -------------  Promesas para obtener los usuarios y los paises ---------------

/**
 *
 * @returns {Promise<unknown>}
 */
function obtenerUsuarios() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(listaUsuarios);
    }, 3000);
  });
}

/**
 *
 * @returns {Promise<unknown>}
 */
function obtenerPaises() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(listaPaises);
    }, 2000);
  });
}

// ---- Consumición de promesas ----------
// quiero cargar primero los usuarios y luego los paises.
// pero por el tiempo de espera tardan menos los paises
obtenerUsuarios().then((respuesta) => console.log("Usuarios: ", respuesta));
obtenerPaises().then((respuesta) => console.log("Paises: ", respuesta));

// para solventar esa demora, voy a encadenar una promesa dentro de otra.

const misUsuarios = obtenerUsuarios();

misUsuarios
  .then((misUsuarios) => {
    console.log("Usuarios:", misUsuarios);
    return obtenerPaises();
  })
  .then((paises) => {
    console.log("Paises:", paises);
  })
  .catch((err) => {
    console.log("Error en el acceso");
  });

// -------------- y como hago esto con Asinc / Await -----------------

async function obtenerInformacion() {
  try {
    const usuarios = await obtenerUsuarios();
    const paises = await obtenerPaises();
    console.log("Usuarios: ", usuarios);
    console.log("Paises:", paises);
  } catch (error) {
    console.log("Error en el acceso");
  }
}

obtenerInformacion();
